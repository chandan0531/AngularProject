package com.example.studnetApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StudnetAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudnetAppApplication.class, args);
	}


}
