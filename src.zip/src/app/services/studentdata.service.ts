import { Injectable } from '@angular/core';


 import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Student } from '../student';


@Injectable({
  providedIn: 'root'
})
export class StudentdataService {

private url = "http://localhost:8000/api/students";

private url2 = "http://localhost:8000/api/student";

  constructor(private httpClient : HttpClient) { 
    
  }

  // getstudents(){
  //   return this.httpClient.get(this.url);
  // }

  getstudents():Observable<Student>{

    return this.httpClient.get<Student>(this.url);
  }


  saveStudent(student : Student): Observable<object>{
    return this.httpClient.post(`${this.url2}`,student);
  }

  

  //getmethod by id
  getStudentById(id:any):Observable<Student>{
    return this.httpClient.get<Student>(`${this.url2}/ ${id}`);
  }

// update method with id
updateStudent(id:any, student:Student):Observable<object>{
  return this.httpClient.put(`${this.url2}/ ${id}`, student);
}
 
}
