export class Student {

    stdId:any;
    firstName:any;
    lastName:any;
    emailId:any;


}
